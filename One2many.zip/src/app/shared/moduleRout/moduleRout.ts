import { Routes } from '@angular/router';

export const moduleRoutes : Routes = [
    { path: 'home', loadChildren: './modules/home/home.module#HomeModule'},
]