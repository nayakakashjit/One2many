'use strict';
angular
    .module('app.core')
    .controller('aboutController', function($scope) {
        //Set page title
        $scope.page = "About";
    });