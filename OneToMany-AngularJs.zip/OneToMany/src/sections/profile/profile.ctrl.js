'use strict';
angular
    .module('app.core')
    .controller('profileController', function($scope) {
        //Set page title
        $scope.page = "Profile";
    });