'use strict';
angular
    .module('app.core')
    .controller('contactController', function($scope) {
        //Set page title
        $scope.page = "Contact";

    });