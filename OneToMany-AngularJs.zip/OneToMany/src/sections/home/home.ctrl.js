'use strict';
angular
    .module('app.core')
    .controller('HomeController', function($scope) {
        //Set page title
        $scope.Page = "Home";

    });
