'use strict';
angular
    .module('app.core')
    .controller('contactController', function($location, $routeParams, ShowService, PageValues) {
        //Set page title and description
        PageValues.title = "contact";
        PageValues.description = "contact for your favorite TV shows.";
        //Setup view model object
        var vm = this;
        vm.query = null;
        vm.shows = [];
        vm.loading = null;
        vm.setcontact = function() {
            var query = encodeURI(vm.query);
            $location.path('/contact/' + query);
        };
        vm.performcontact = function(query) {
            vm.loading = true;
            ShowService.contact(query).then(function(response){
                vm.shows = response;
                vm.loading = false;
            });
        };
        if (typeof $routeParams.query != "undefined") {
            vm.performcontact($routeParams.query);
            vm.query = decodeURI($routeParams.query);
        }
    });