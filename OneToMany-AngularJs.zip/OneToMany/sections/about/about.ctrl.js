'use strict';
angular
    .module('app.core')
    .controller('aboutController', function($scope, PageValues, shows) {
        //Set page title and description
        PageValues.title = "about";
        PageValues.description = "The most about TV shows.";
        //Setup view model object
        var vm = this;
        vm.shows = shows;
    });