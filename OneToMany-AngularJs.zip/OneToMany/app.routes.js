'use strict';

angular
    .module('app.routes', ['ngRoute'])
    .config(config);

function config ($routeProvider) {
    $routeProvider.
        when('/', {
            templateUrl: 'sections/home/home.tpl.html',
            controller: 'HomeController as home'
        })
        .when('/profile', {
            templateUrl: 'sections/profile/profile.tpl.html',
            controller: 'profileController as profile',
            resolve: {
                shows: function(ShowService) {
                    return ShowService.getprofile();
                }
            }
        })
        .when('/contact', {
            templateUrl: 'sections/contact/contact.tpl.html',
            controller: 'contactController as contact'
        })
        .when('/contact/:query', {
            templateUrl: 'sections/contact/contact.tpl.html',
            controller: 'contactController as contact'
        })
        .when('/about', {
            templateUrl: 'sections/about/about.tpl.html',
            controller: 'aboutController as about',
            resolve: {
                shows: function(ShowService) {
                    return ShowService.getabout();
                }
            }
        })
        .when('/view/:id', {
            templateUrl: 'sections/view/view.tpl.html',
            controller: 'ViewController as view',
            resolve: {
                show: function(ShowService, $route) {
                    return ShowService.get($route.current.params.id);
                }
            }
        })
        .otherwise({
            redirectTo: '/'
        });
}